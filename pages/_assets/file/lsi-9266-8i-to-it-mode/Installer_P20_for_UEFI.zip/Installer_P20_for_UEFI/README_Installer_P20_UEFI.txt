***************************************************************************************************************************

Installer for EFI

LSI Corporation SAS2FLASH Release

***************************************************************************************************************************
=============================
Contents-
=============================
Installer fOr EFI (SAS2FLASH)    :  \sas2flash_efi_ebc_rel\sas2flash.efi    Version:20.00.00.00        Release Date:18-SEP-14
README_FOR_Installer_P20_UEFI.txt
SAS2Flash_ReferenceGuide.pdf
SAS2FLASH_Phase20.0-20.00.00.00.pdf


Installation:
=============

SAS2FLASH is stand-alone binary and can be executed from any location on a file system. For more details on installer please refer to the SAS2FLASH User manual included in this package.
 





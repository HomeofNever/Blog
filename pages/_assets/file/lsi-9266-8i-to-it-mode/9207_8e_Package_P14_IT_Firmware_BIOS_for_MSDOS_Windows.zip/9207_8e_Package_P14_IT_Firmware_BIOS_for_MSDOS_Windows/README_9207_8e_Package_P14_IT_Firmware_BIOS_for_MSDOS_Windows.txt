************************************************************************************************************************
Package for P14 Firmware BIOS Upgrade on MSDOS & Windows
************************************************************************************************************************
LSI Host Bus Adapter(HBA) - LSI SAS 9207_8e

Package Contents- 

Readme first note      :  README_9207_8e_Package_P14_IT_Firmware_BIOS_for_MSDOS_Windows.txt 

Installer(SAS2FLSH)    :  \sas2flash_dos_rel\sas2flsh                   Version no: 14.00.00.00     Release date: 04-JULY-12
Installer(SAS2FLASH)   :  \sas2flash_win_x86_rel\sas2flash              Version no: 14.00.00.00     Release date: 04-JULY-12 
Installer(SAS2FLASH)   :  \sas2flash_win_x64_rel\sas2flash              Version no: 14.00.00.00     Release date: 04-JULY-12 
Installer(SAS2FLASH)   :  \sas2flash_win_ia64_rel\sas2flash             Version no: 14.00.00.00     Release date: 04-JULY-12

Reference Guide        :  SAS2Flash_ReferenceGuide.pdf                  Version no: 2.1             Release date: JUNE-11

Firmware               :  \firmware\HBA_9207_8e_IT\9207_8e.bin          Version no: 14.00.01.00     Release date: 18-SEP-12

BIOS                   :  \sasbios_rel\mptsas2.rom                      Version no: 7.27.00.00      Release date: 02-JULY-12
Readme for BIOS        :  \sasbios_rel\mptbios.txt                      Version no: NA              Release date: NA
Release notes          :  SAS2BIOS_Release_Notes_P14.txt, Firmware_Release_Notes_P14.txt, SAS2FLASH_Release_Notes_P14.txt 

----------------------------------------------------------------------------------------------------------------------------

